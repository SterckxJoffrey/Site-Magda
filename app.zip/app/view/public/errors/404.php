<body class="error_page">
  <main class="error-wrapper">
    <h1>404</h1>
    <h2><?= $t['404_title'] ?></h2>
    <p><?= $t['404_message'] ?></p>
    <a href="/" class="button-home" aria-label="<?= $t['404_back_home'] ?>"><?= $t['404_back_home'] ?></a>
  </main>
</body>

