
  const phone = "+32494995818";
  const display = "+32 494 99 58 18";
  document.getElementById("phone-link").innerHTML =
    `<a href="tel:${phone}">${display}</a>`;

